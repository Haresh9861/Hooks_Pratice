

export default function Landing() {
    return <div>
        Landing page
    </div>
}